// Using Thread Class
class MyThread extends Thread {
    public void run() {
        System.out.println("Thread using Thread class is running.");
    }
}

// Using Runnable Interface
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread using Runnable interface is running.");
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        MyThread thread1 = new MyThread();
        thread1.start();

        Thread thread2 = new Thread(new MyRunnable());
        thread2.start();
    }
}
