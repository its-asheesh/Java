public class StudentRecord {
    public static void main(String[] args) {
        if (args.length != 5) {
            System.out.println("Usage: java StudentRecord <name> <rollNumber> <marks1> <marks2> <marks3>");
            return;
        }

        String name = args[0];
        String rollNumber = args[1];
        int marks1 = Integer.parseInt(args[2]);
        int marks2 = Integer.parseInt(args[3]);
        int marks3 = Integer.parseInt(args[4]);

        int totalMarks = calculateTotal(marks1, marks2, marks3);
        double averageMarks = calculateAverage(totalMarks, 3);

        printStudentRecord(name, rollNumber, marks1, marks2, marks3, totalMarks, averageMarks);
    }

    private static int calculateTotal(int marks1, int marks2, int marks3) {
        return marks1 + marks2 + marks3;
    }

    private static double calculateAverage(int totalMarks, int numberOfSubjects) {
        return (double) totalMarks / numberOfSubjects;
    }

    private static void printStudentRecord(String name, String rollNumber, int marks1, int marks2, int marks3,
            int totalMarks, double averageMarks) {
        System.out.println("Student Record:");
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Marks1: " + marks1);
        System.out.println("Marks2: " + marks2);
        System.out.println("Marks3: " + marks3);
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + averageMarks);
    }
}
