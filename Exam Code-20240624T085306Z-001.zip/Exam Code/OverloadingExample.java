class OverloadingExample {
    void display(int num) {
        System.out.println("Display method with integer argument: " + num);
    }

    void display(String str) {
        System.out.println("Display method with string argument: " + str);
    }

    public static void main(String[] args) {
        OverloadingExample obj = new OverloadingExample();
        obj.display(10);
        obj.display("Hello");
    }
}
