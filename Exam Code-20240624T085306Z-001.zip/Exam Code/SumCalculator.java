import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SumCalculator {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Sum Calculator");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(3, 2));

        JLabel label1 = new JLabel("Number 1:");
        JTextField text1 = new JTextField();
        JLabel label2 = new JLabel("Number 2:");
        JTextField text2 = new JTextField();
        JButton button = new JButton("Calculate Sum");
        JLabel result = new JLabel("Result:");

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int num1 = Integer.parseInt(text1.getText());
                    int num2 = Integer.parseInt(text2.getText());
                    int sum = num1 + num2;
                    result.setText("Result: " + sum);
                } catch (NumberFormatException ex) {
                    result.setText("Invalid input");
                }
            }
        });

        frame.add(label1);
        frame.add(text1);
        frame.add(label2);
        frame.add(text2);
        frame.add(button);
        frame.add(result);

        frame.setVisible(true);
    }
}
