class MyException extends Exception {
    MyException(String message) {
        super(message);
    }
}

public class UserDefinedExceptionExample {
    public static void main(String[] args) {
        try {
            throw new MyException("This is a user defined exception");
        } catch (MyException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("This is the finally block.");
        }
    }
}
