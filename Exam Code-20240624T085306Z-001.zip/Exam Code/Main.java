// Save this file as MyPackage.java in a directory named 'mypackage'
package mypackage;

public class MyPackage {
    public void display() {
        System.out.println("This is my package!");
    }
}

// Save this file as Main.java
import mypackage.MyPackage;

public class Main {
    public static void main(String[] args) {
        MyPackage obj = new MyPackage();
        obj.display();
    }
}
