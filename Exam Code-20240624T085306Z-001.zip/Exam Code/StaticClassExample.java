public class StaticClassExample {
    static class NestedStaticClass {
        public void display() {
            System.out.println("This is a nested static class.");
        }
    }

    public static void main(String[] args) {
        StaticClassExample.NestedStaticClass nestedClass = new StaticClassExample.NestedStaticClass();
        nestedClass.display();
    }
}
