public class CountOfTwoNumbers {
    public boolean compareCountOf(int[] arr, int arg1, int arg2) {
        int count1 = 0, count2 = 0;
        for (int num : arr) {
            if (num == arg1) {
                count1++;
            }
            if (num == arg2) {
                count2++;
            }
        }
        return count1 > count2;
    }

    public static void main(String[] args) {
        CountOfTwoNumbers obj = new CountOfTwoNumbers();
        int[] arr = {1, 2, 3, 1, 2, 1, 3, 1};
        System.out.println(obj.compareCountOf(arr, 1, 2)); // Output: true
    }
}
