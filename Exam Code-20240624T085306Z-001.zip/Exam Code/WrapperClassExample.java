public class WrapperClassExample {
    public static void main(String[] args) {
        // Autoboxing
        int num = 100;
        Integer obj = num; // Autoboxing
        System.out.println("Integer object: " + obj);

        // Unboxing
        Integer obj2 = new Integer(200);
        int num2 = obj2; // Unboxing
        System.out.println("Primitive int: " + num2);
    }
}
