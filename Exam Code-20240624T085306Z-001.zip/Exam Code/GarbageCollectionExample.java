public class GarbageCollectionExample {
    public static void main(String[] args) {
        GarbageCollectionExample obj1 = new GarbageCollectionExample();
        obj1 = null;

        System.gc();

        System.out.println("End of main method.");
    }

    @Override
    protected void finalize() {
        System.out.println("finalize method called.");
    }
}
