class Parent {
    void display() {
        System.out.println("Display method in parent class.");
    }
}

class Child extends Parent {
    @Override
    void display() {
        System.out.println("Display method in child class.");
    }
}

public class OverridingExample {
    public static void main(String[] args) {
        Parent obj = new Child();
        obj.display();
    }
}
