class Parent {
    Parent() {
        System.out.println("Parent class constructor called.");
    }

    Parent(String message) {
        System.out.println("Parent class constructor called with message: " + message);
    }
}

class Child extends Parent {
    Child() {
        super("Hello from Parent!");
        System.out.println("Child class constructor called.");
    }

    Child(String message) {
        super(message);
        System.out.println("Child class constructor called with message: " + message);
    }
}

public class ConstructorInheritanceExample {
    public static void main(String[] args) {
        Child obj1 = new Child();
        Child obj2 = new Child("Hello from Child!");
    }
}
