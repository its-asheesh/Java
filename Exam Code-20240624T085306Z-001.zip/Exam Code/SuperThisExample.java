class Parent {
    int num = 100;

    void display() {
        System.out.println("This is the display method of parent class.");
    }
}

class Child extends Parent {
    int num = 200;

    void display() {
        System.out.println("This is the display method of child class.");
    }

    void print() {
        this.display();
        super.display();
        System.out.println("Value of num in child class: " + this.num);
        System.out.println("Value of num in parent class: " + super.num);
    }
}

public class SuperThisExample {
    public static void main(String[] args) {
        Child obj = new Child();
        obj.print();
    }
}
